package cr.ac.ucenfotec.tl;
import cr.ac.ucenfotec.bl.entities.Casa.Casa;
import cr.ac.ucenfotec.bl.entities.Superadministrador.Superadministrador;
import cr.ac.ucenfotec.bl.entities.Vecino.Vecino;
import cr.ac.ucenfotec.bl.logic.CasaGestor;
import cr.ac.ucenfotec.bl.logic.VecinoGestor;
import cr.ac.ucenfotec.ui.UI;

import java.time.LocalDate;

public class Controller {
    public UI interfaz;
    public CasaGestor gestorCasa;
    public VecinoGestor gestorVecino;
    public String dni;

    public Controller() {
        interfaz = new UI();
        gestorCasa = new CasaGestor();
        gestorVecino = new VecinoGestor();

    }

    public void start() {
        boolean Vecino = (boolean) iniciarSesionVecino();
        if (Vecino) {
            Vecino vecinoEncontrado = gestorVecino.buscarVecino(dni);

            gestorVecino.mostrarDatosVecino(vecinoEncontrado).forEach(System.out::println);
            gestorCasa.enlistarCasa().forEach(System.out::println);
            muestraMenu();
        } else {
            System.out.println(" Lo siento, no te encuentras en el sistema :( ");
        }

    }

    public Object iniciarSesionVecino() {

        System.out.println("*** Iniciar Sesión como Vecino ***");
        System.out.print("Ingrese su DNI: ");
        dni = interfaz.leerTexto();

        if (gestorVecino.buscarCredencialPorDni(dni)) {
            System.out.print("Ingrese su correo electrónico: ");
            String correoElectronico = interfaz.leerTexto();
            System.out.print("Ingrese su contraseña: ");
            String contrasenia = interfaz.leerTexto();

            // Verificar las credenciales del vecino
            boolean vecino = gestorVecino.buscarCredenciales(correoElectronico, contrasenia);
            return vecino; // Devolver el vecino si las credenciales son correctas
        } else {
            System.out.println("El DNI ingresado no está en el sistema.");
            return false; // Devolver null si el DNI no está en el sistema
        }
    }

    private void muestraMenu() {
        int opcion = 0;
        do {
            interfaz.mostrarMenu();
            opcion = interfaz.leerNumero();
            procesarOpcion(opcion);
        } while (opcion != 0);
    }

    private void procesarOpcion(int opcion) {
        try {
            switch (opcion) {
                case 1:
                    registrarVecino();
                    break;
                case 2:
                    listarVecino();
                    break;
                case 3:
                    RegistrarCasa();
                    break;
                case 4:
                    enlistarCasa();
                    break;
                case 5:
                    registrarAlarma();
                    break;
                case 6:
                    vincularVecinoCasa();
                    break;
                case 0:
                    interfaz.imprimirMensaje("Gracias por su visita!");
                    break;
                default:
                    interfaz.imprimirMensaje("Opción inválida. Intente de nuevo con otra opción.");
            }
        } catch (Exception e) {
            e.printStackTrace(); // Manejo de la excepción
        }
    }
    public void registrarVecino() {
        interfaz.imprimirMensaje("Digite su número de identidad: ");
        String idVecino = interfaz.leerTexto();
        interfaz.imprimirMensaje("Digite su nombre: ");
        String nombreVecino = interfaz.leerTexto();
        interfaz.imprimirMensaje("Digite su apellido: ");
        String apellidoVecino = interfaz.leerTexto();
        interfaz.imprimirMensaje("Digite su fecha de nacimiento (YYYY-MM-DD): ");
        LocalDate fechaNacimiento = interfaz.leerFecha();
        interfaz.imprimirMensaje("Digite su género (F-M-N): ");
        char genero = interfaz.leerCaracter();
        interfaz.imprimirMensaje("Digite su número de teléfono: ");
        String telefono = interfaz.leerTexto();
        interfaz.imprimirMensaje("Digite el Correo Electrónico: ");
        String correoElectronico = interfaz.leerTexto();
        interfaz.imprimirMensaje("Digite una contraseña: ");
        String contrasenia = interfaz.leerTexto();
        interfaz.imprimirMensaje("Digite el id del credencial");
        String idCredencial = interfaz.leerTexto();

        String mensajeVecino = gestorVecino.registrarVecino(idVecino, nombreVecino, apellidoVecino, fechaNacimiento, genero, telefono, correoElectronico, contrasenia, idCredencial);
        interfaz.imprimirMensaje(mensajeVecino);


    }

    public void listarVecino() {
        interfaz.imprimirMensaje("***Información de los vecinos registrados***");
        for (Vecino vecinoTemp: gestorVecino.listarVecino()){
            System.out.println(vecinoTemp.toString());

        }
    }

    public void RegistrarCasa() {
        interfaz.imprimirMensaje("**** Registro de casas ****");
        interfaz.imprimirMensaje("Digite el número de identificación de la casa");
        String idCasa = interfaz.leerTexto();
        interfaz.imprimirMensaje("Digite la dirección exacta");
        String direccion = interfaz.leerTexto();
        interfaz.imprimirMensaje("Digite los detalles del encargado de la seguridad para evitar inconvenientes.");
        String detalles = interfaz.leerTexto();
        interfaz.imprimirMensaje ("Digite el id del encargado de la casa!!!");
        String vecinoEncargado = interfaz.leerTexto();

        String mensajeCasa = gestorCasa.RegistrarCasa(idCasa, direccion, detalles, vecinoEncargado);
        interfaz.imprimirMensaje(mensajeCasa);


    }
    public void enlistarCasa() {
        interfaz.imprimirMensaje("***Información de las casas registradas***");
        for (Casa CasaTemp: gestorCasa.enlistarCasa()){
            System.out.println(CasaTemp.toString());

        }
    }
    public void registrarAlarma() {
        interfaz.imprimirMensaje("**** Registro de Alarmas ****");
        interfaz.imprimirMensaje("Debe ser encargado de una casa para registrar Alarma!");

        interfaz.imprimirMensaje("Digite el ID de la casa a la que desea vincular la alarma");
        String idCasa = interfaz.leerTexto();
        interfaz.imprimirMensaje("Digite el ID del encargado de la casa");
        String vecinoEncargado = interfaz.leerTexto();

        // Verifico si el ID es correcto
        Casa casa = gestorCasa.buscarCasa(idCasa);
        if (casa != null && vecinoEncargado.equals(casa.getVecinoEncargado())) {
            interfaz.imprimirMensaje("Ya puedes registrar la alarma!!!");
            interfaz.imprimirMensaje("Digite el ID de la Alarma");
            String idAlarma = interfaz.leerTexto();
            interfaz.imprimirMensaje("Digite la ubicación exacta");
            String ubicacion = interfaz.leerTexto();
            interfaz.imprimirMensaje("Digite las medidas sugeridas de precaución");
            String medidasPrecaucion = interfaz.leerTexto();
            interfaz.imprimirMensaje("Digite el tipo de incidente");
            String incidente = interfaz.leerTexto();
            interfaz.imprimirMensaje("Digite el id de la casa a la que desea vincular la alarma.");
            idCasa = interfaz.leerTexto();

            String mensajeAlarma = gestorCasa.registrarAlarma(idAlarma, ubicacion, medidasPrecaucion, incidente, idCasa);
            interfaz.imprimirMensaje(mensajeAlarma);
        } else {
            interfaz.imprimirMensaje("ID de la casa o del encargado es incorrecto!!!");
        }
    }



        public void vincularVecinoCasa () {
            interfaz.imprimirMensaje("***Vincular un vecino a una casa!!!***");
            interfaz.imprimirMensaje("Digite el número de ID de la casa que desea vincular: ");
            String idCasa = interfaz.leerTexto();
            interfaz.imprimirMensaje("Digite el número de ID del vecino que desea vincular: ");
            String idVecino = interfaz.leerTexto();

            Vecino vecino = gestorVecino.buscarVecino(idVecino);

            if (vecino != null) {
                String mensaje = gestorCasa.vincularVecinoCasa(idCasa, vecino);
                interfaz.imprimirMensaje(mensaje);
            } else {
                interfaz.imprimirMensaje("El vecino con el id " + idVecino + ", no está en el sistema!");
            }
        }

    }

